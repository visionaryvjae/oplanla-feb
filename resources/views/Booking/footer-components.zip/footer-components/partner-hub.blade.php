@extends('layouts.app')

@section('content')
    <style>
        /* Custom colors for Tailwind */
        :root {
            --color-primary-p: #ad68e4;
            --color-complimentary: #68e4ad;
            --color-dark-bg: #282c34; /* Dark background from footer image */
            --color-text-light: #e0e0e0; /* Light text for dark backgrounds */
            --color-text-dark: #333333; /* Dark text for light backgrounds */
        }
        .bg-primary-p { background-color: var(--color-primary-p); }
        .text-primary-p { color: var(--color-primary-p); }
        .hover\:bg-primary-p-darker:hover { background-color: #973fdf; /* Slightly darker primary-p */ }
        .bg-complimentary { background-color: var(--color-complimentary); }
        .text-complimentary { color: var(--color-complimentary); }
        .bg-dark-bg { background-color: var(--color-dark-bg); }
        .text-text-light { color: var(--color-text-light); }
        .text-text-dark { color: var(--color-text-dark); }

        /* Inter font */
        body {
            font-family: 'Inter', sans-serif;
            color: var(--color-text-dark);
        }
    </style>

    <main class="flex-grow container mx-auto px-4 py-8">    
        <h1 class="text-4xl font-extrabold mb-8 text-center text-dark-bg">Welcome to the Oplanla.com Partner Hub</h1>
        <p class="text-lg text-center mb-12 max-w-3xl mx-auto text-gray-700">
            Your central resource for managing your listings, understanding your performance, and connecting with the Oplanla.com community.
        </p>

        {{-- Blade @auth directive would typically check if a partner is logged in --}}
        @php
            $isPartnerLoggedIn = true; // Replace with actual Laravel auth check for partners
            $partnerName = 'Acme Stays'; // Replace with actual partner name
        @endphp

        @if($isPartnerLoggedIn)
            <!-- Content for Logged-in Partner -->
            <div class="max-w-6xl mx-auto bg-white p-8 rounded-xl shadow-lg">
                <h2 class="text-3xl font-bold mb-6 text-dark-bg">Hello, {{ $partnerName }}!</h2>
                <p class="text-gray-700 mb-8">Here's a quick overview of your property's performance and quick links to manage your listings.</p>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
                    <!-- Stat Card 1 -->
                    <div class="bg-gray-50 p-6 rounded-lg shadow-sm text-center">
                        <p class="text-5xl font-bold text-primary-p mb-2">15</p>
                        <p class="text-gray-600">Upcoming Bookings</p>
                    </div>
                    <!-- Stat Card 2 -->
                    <div class="bg-gray-50 p-6 rounded-lg shadow-sm text-center">
                        <p class="text-5xl font-bold text-complimentary mb-2">R 12,500</p>
                        <p class="text-gray-600">Pending Payouts</p>
                    </div>
                    <!-- Stat Card 3 -->
                    <div class="bg-gray-50 p-6 rounded-lg shadow-sm text-center">
                        <p class="text-5xl font-bold text-blue-500 mb-2">4.8</p>
                        <p class="text-gray-600">Average Rating</p>
                    </div>
                    <!-- Stat Card 4 -->
                    <div class="bg-gray-50 p-6 rounded-lg shadow-sm text-center">
                        <p class="text-5xl font-bold text-purple-500 mb-2">3</p>
                        <p class="text-gray-600">Active Listings</p>
                    </div>
                </div>

                <h3 class="text-2xl font-bold mb-4 text-dark-bg">Quick Links</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                    <a href="/partner/listings" class="bg-primary-p text-white font-semibold py-3 px-6 rounded-lg hover:bg-primary-p-darker transition duration-300 text-center">Manage Listings</a>
                    <a href="/partner/bookings" class="bg-complimentary text-white font-semibold py-3 px-6 rounded-lg hover:bg-green-600 transition duration-300 text-center">View All Bookings</a>
                    <a href="/partner/payments" class="bg-blue-500 text-white font-semibold py-3 px-6 rounded-lg hover:bg-blue-600 transition duration-300 text-center">Payment History</a>
                    <a href="/partner/reports" class="bg-red-500 text-white font-semibold py-3 px-6 rounded-lg hover:bg-purple-600 transition duration-300 text-center">Performance Reports</a>
                    <a href="/help-centre?for=partners" class="bg-gray-300 text-dark-bg font-semibold py-3 px-6 rounded-lg hover:bg-gray-400 transition duration-300 text-center">Help Articles</a>
                    <a href="/community-forum" class="bg-orange-400 text-white font-semibold py-3 px-6 rounded-lg hover:bg-orange-500 transition duration-300 text-center">Community Forum</a>
                </div>

                <div class="mt-12 text-center">
                    <h3 class="text-2xl font-bold mb-4 text-dark-bg">Need Assistance?</h3>
                    <p class="text-gray-700 mb-6">Our dedicated partner support team is here to help you succeed.</p>
                    <a href="mailto:partnersupport@oplanla.com" class="inline-block bg-primary-p text-white font-semibold py-3 px-6 rounded-lg hover:bg-primary-p-darker transition duration-300">Contact Partner Support</a>
                </div>
            </div>
        @else
            <!-- Content for Not Logged-in Partner -->
            <div class="max-w-md mx-auto bg-white p-8 rounded-xl shadow-lg">
                <h2 class="text-3xl font-bold mb-6 text-center text-dark-bg">Partner Login</h2>
                <form action="/partner/login" method="POST" class="space-y-4">
                    @csrf {{-- Laravel CSRF token --}}
                    <div>
                        <label for="partner_email" class="block text-gray-700 text-sm font-bold mb-2">Email Address</label>
                        <input type="email" id="partner_email" name="email" class="shadow appearance-none border rounded-lg w-full py-3 px-4 text-gray-700 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-p" placeholder="your.partner.email@example.com" required>
                    </div>
                    <div>
                        <label for="partner_password" class="block text-gray-700 text-sm font-bold mb-2">Password</label>
                        <input type="password" id="partner_password" name="password" class="shadow appearance-none border rounded-lg w-full py-3 px-4 text-gray-700 mb-3 leading-tight focus:outline-none focus:shadow-outline focus:border-primary-p" placeholder="********" required>
                    </div>
                    <div class="flex items-center justify-between">
                        <button type="submit" class="bg-primary-p text-white font-bold py-3 px-6 rounded-lg focus:outline-none focus:shadow-outline hover:bg-primary-p-darker transition duration-300 w-full">
                            Login to Partner Hub
                        </button>
                    </div>
                    <div class="text-center mt-4">
                        <a href="/partner/forgot-password" class="inline-block align-baseline font-bold text-sm text-primary-p hover:text-primary-p-darker">
                            Forgot Partner Password?
                        </a>
                    </div>
                </form>
                <div class="text-center mt-6">
                    <p class="text-gray-700">New to Oplanla.com?</p>
                    <a href="/list-property" class="font-bold text-primary-p hover:text-primary-p-darker">List your property and become a partner today!</a>
                </div>
            </div>

            <div class="max-w-4xl mx-auto mt-16 bg-white p-8 rounded-xl shadow-lg text-center">
                <h2 class="text-3xl font-bold mb-6 text-dark-bg">Information for Prospective Partners</h2>
                <p class="text-lg text-gray-700 mb-6">
                    Learn how to optimize your listing and maximize your bookings, and explore the many benefits of partnering with Oplanla.com.
                </p>
                <div class="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-6">
                    <a href="/why-host" class="bg-complimentary text-white font-semibold py-3 px-6 rounded-lg hover:bg-green-600 transition duration-300 flex items-center justify-center min-w-[200px]">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-1 17.93c-3.95-.49-7-3.85-7-7.93h7v7.93zm1-15.93c3.95.49 7 3.85 7 7.93h-7V4.07z"/></svg>
                        Why Host With Us
                    </a>
                    <a href="/list-property" class="bg-primary-p text-white font-semibold py-3 px-6 rounded-lg hover:bg-primary-p-darker transition duration-300 flex items-center justify-center min-w-[200px]">
                        <svg class="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm0 15c-2.76 0-5-2.24-5-5s2.24-5 5-5 5 2.24 5 5-2.24 5-5 5z"/></svg>
                        List Your Property
                    </a>
                </div>
            </div>
        @endif
    </main>
@endsection